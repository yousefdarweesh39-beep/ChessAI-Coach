import os
import shutil
import threading
from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput

try:
    import chess
    import chess.pgn
    import chess.engine
except Exception:
    chess = None

KV = r"""
<RootUI>:
    orientation: "vertical"
    padding: "10dp"
    spacing: "7dp"
    canvas.before:
        Color:
            rgba: .055, .07, .095, 1
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        size_hint_y: None
        height: "44dp"
        Label:
            text: "[b]CHESS AI COACH[/b]"
            markup: True
            font_size: "20sp"
            color: .94,.96,1,1
            halign: "left"
        Label:
            text: "STOCKFISH 19"
            font_size: "11sp"
            color: .3,.85,.62,1
            size_hint_x: .42
    Label:
        text: root.status
        size_hint_y: None
        height: "38dp"
        color: .78,.84,.93,1
        text_size: self.width, None
        halign: "left"
    GridLayout:
        id: board
        cols: 8
        spacing: "1dp"
        size_hint_y: None
        height: min(self.width, root.height * .52)
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        spacing: "5dp"
        Button:
            text: "Import PGN/FEN"
            on_release: root.open_import()
        Button:
            text: "Reset"
            on_release: root.reset_board()
        Button:
            text: "Flip"
            on_release: root.flip_board()
    BoxLayout:
        size_hint_y: None
        height: "46dp"
        Button:
            text: "Analyze with Stockfish 19"
            background_color: .12,.55,.36,1
            on_release: root.analyze()
    Label:
        text: root.analysis
        color: .93,.95,1,1
        halign: "left"
        valign: "top"
        text_size: self.width, self.height
    Label:
        text: "Training and post-game analysis. No hidden live-game assistance."
        font_size: "10sp"
        color: .55,.62,.72,1
        size_hint_y: None
        height: "22dp"
"""

class RootUI(BoxLayout):
    status = StringProperty("Ready • Import PGN/FEN or play a training position")
    analysis = StringProperty("Stockfish 19 engine will be checked when you analyze.")
    flipped = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.board_obj = chess.Board() if chess else None
        self.selected = None
        self.best_move = None
        self.engine_path = None
        Clock.schedule_once(self.draw_board, .2)

    def _prepare_engine(self):
        app = App.get_running_app()
        target_dir = os.path.join(app.user_data_dir, "engine")
        os.makedirs(target_dir, exist_ok=True)
        target = os.path.join(target_dir, "stockfish")
        if os.path.isfile(target) and os.access(target, os.X_OK):
            self.engine_path = target
            return target
        # Buildozer packages this extensionless executable using source.include_patterns.
        from kivy.resources import resource_find
        bundled = resource_find("assets/engine/stockfish")
        if not bundled or not os.path.isfile(bundled):
            raise FileNotFoundError(
                "Stockfish binary is not packaged. Check GitHub Actions download and build artifacts."
            )
        bundle_dir = os.path.dirname(bundled)
        shutil.copyfile(bundled, target)
        os.chmod(target, 0o700)
        # Stockfish releases may ship NNUE network files beside the executable.
        # Copy them too, preserving the engine's expected relative layout.
        for filename in os.listdir(bundle_dir):
            if filename.lower().endswith(".nnue"):
                shutil.copyfile(
                    os.path.join(bundle_dir, filename),
                    os.path.join(target_dir, filename)
                )
        self.engine_path = target
        return target

    def draw_board(self, *_):
        if not chess:
            self.status = "python-chess dependency is unavailable"
            return
        grid = self.ids.board
        grid.clear_widgets()
        squares = list(chess.SQUARES_180 if self.flipped else chess.SQUARES)
        for sq in squares:
            piece = self.board_obj.piece_at(sq)
            row, col = chess.square_rank(sq), chess.square_file(sq)
            is_light = (row + col) % 2 == 1
            bg = (.88,.86,.77,1) if is_light else (.29,.39,.34,1)
            if self.best_move and sq in (self.best_move.from_square, self.best_move.to_square):
                bg = (.78,.68,.25,1)
            symbol = self.piece_symbol(piece)
            btn = Button(text=symbol, font_size="27sp", background_normal="", background_color=bg)
            btn.bind(on_release=lambda b, s=sq: self.square_tap(s))
            grid.add_widget(btn)

    def piece_symbol(self, piece):
        if not piece: return ""
        symbols = {chess.PAWN:"♟", chess.KNIGHT:"♞", chess.BISHOP:"♝",
                   chess.ROOK:"♜", chess.QUEEN:"♛", chess.KING:"♚"}
        return symbols[piece.piece_type]

    def square_tap(self, sq):
        if self.selected is None:
            if self.board_obj.piece_at(sq):
                self.selected = sq
                self.status = f"Selected {chess.square_name(sq)} • choose a legal destination"
            return
        move = chess.Move(self.selected, sq)
        if move in self.board_obj.legal_moves:
            self.board_obj.push(move)
            self.best_move = None
            self.analysis = "Position changed. Analyze again."
            self.status = "Training move played"
        else:
            self.status = "Illegal move. Select a piece and legal destination."
        self.selected = None
        self.draw_board()

    def open_import(self):
        box = BoxLayout(orientation="vertical", padding=10, spacing=8)
        inp = TextInput(hint_text="Paste FEN or PGN here", multiline=True)
        box.add_widget(inp)
        row = BoxLayout(size_hint_y=None, height="44dp", spacing=8)
        pop = Popup(title="Import PGN / FEN", content=box, size_hint=(.94,.72))
        def load(_):
            try:
                value = inp.text.strip()
                if not value: return
                if "/" in value.splitlines()[0] and len(value.splitlines()[0].split()) >= 4:
                    self.board_obj = chess.Board(value.splitlines()[0])
                else:
                    import io
                    game = chess.pgn.read_game(io.StringIO(value))
                    if game is None: raise ValueError("No valid PGN found")
                    self.board_obj = game.end().board()
                self.best_move = None
                self.selected = None
                self.analysis = "Position imported. Ready for Stockfish analysis."
                self.status = "Position loaded"
                self.draw_board()
                pop.dismiss()
            except Exception as exc:
                self.status = f"Import error: {exc}"
        row.add_widget(Button(text="Load", on_release=load))
        row.add_widget(Button(text="Cancel", on_release=pop.dismiss))
        box.add_widget(row)
        pop.open()

    def reset_board(self):
        self.board_obj = chess.Board()
        self.selected = None
        self.best_move = None
        self.analysis = "Starting position restored."
        self.status = "New training position"
        self.draw_board()

    def flip_board(self):
        self.flipped = not self.flipped
        self.draw_board()

    def analyze(self):
        if not self.board_obj or self.board_obj.is_game_over():
            self.status = "Load a playable position first"
            return
        self.status = "Starting Stockfish 19…"
        self.analysis = "Analyzing for up to 5 seconds."
        fen = self.board_obj.fen()
        threading.Thread(target=self._engine_worker, args=(fen,), daemon=True).start()

    def _engine_worker(self, fen):
        text = ""
        move_uci = None
        engine = None
        try:
            path = self._prepare_engine()
            board = chess.Board(fen)
            engine = chess.engine.SimpleEngine.popen_uci(path)
            engine.configure({"Threads": 2, "Hash": 128})
            info = engine.analyse(board, chess.engine.Limit(time=5.0))
            pv = info.get("pv", [])
            move = pv[0] if pv else None
            if move:
                move_uci = move.uci()
                san = board.san(move)
                line = " ".join(board.variation_san(pv[:8]))
                score = info["score"].white()
                text = (f"Best move: {san}  ({move_uci})\\n"
                        f"Evaluation: {score}\\nDepth: {info.get('depth', '—')}\\n"
                        f"Line: {line}")
            else:
                text = "The engine returned no legal move for this position."
        except Exception as exc:
            text = f"Stockfish error: {exc}"
        finally:
            if engine:
                try: engine.quit()
                except Exception: pass
        Clock.schedule_once(lambda dt: self._show_result(text, move_uci), 0)

    def _show_result(self, text, move_uci):
        self.analysis = text
        self.status = "Analysis complete" if move_uci else "Engine did not complete"
        self.best_move = chess.Move.from_uci(move_uci) if move_uci else None
        self.draw_board()

class ChessAICoachApp(App):
    def build(self):
        self.title = "Chess AI Coach"
        Builder.load_string(KV)
        return RootUI()

if __name__ == "__main__":
    ChessAICoachApp().run()
