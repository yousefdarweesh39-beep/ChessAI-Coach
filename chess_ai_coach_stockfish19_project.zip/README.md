# Chess AI Coach 0.2.0

Training and post-game analysis Android app using Kivy, python-chess and the official Stockfish 19 Android ARM64 universal binary.

## Engine integration
The GitHub Actions workflow downloads the official Stockfish 19 Android ARM64 archive from the official Stockfish GitHub release (`sf_19`), extracts the `stockfish` executable into `assets/engine/stockfish`, and packages it in the APK. At runtime, the app copies it into its private app data directory, marks it executable, and starts it through the UCI protocol using python-chess.

Stockfish is GPLv3. The official source is https://github.com/official-stockfish/Stockfish/tree/sf_19 . If distributing this APK, include the GPLv3 license and make the corresponding source and build information available as required by the license.

## Build
Push to `main` or manually run the `Build Chess AI Coach` workflow from GitHub Actions. The APK is uploaded as an Actions artifact.

## Current scope and limitations
- PGN/FEN import, interactive legal moves, Stockfish best move/evaluation/PV, and board-square highlighting for the best move.
- The camera and screen-capture pipelines are not implemented in this version. Automatic board recognition needs a separate computer-vision model and calibration/testing.
- No live competitive-game assistance or hidden move overlay is included.
- Android process execution of native binaries must be validated on the target phone. This workflow packages the official ARM64 binary, but a successful GitHub build alone does not prove runtime compatibility.
- Analysis time is best-effort; device thermal state, position complexity, and CPU capability affect speed.
