[app]
title = Chess AI Coach
package.name = chessaicoach
package.domain = org.chessaicoach
source.dir = .
source.include_exts = py,kv,png,jpg,jpeg,txt,md,nnue
source.include_patterns = assets/engine/stockfish, assets/engine/*.nnue
version = 0.2.0
requirements = python3,kivy==2.3.1,python-chess==1.999,plyer==2.1.0
orientation = portrait
fullscreen = 0
android.permissions = CAMERA
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.accept_sdk_license = True
p4a.branch = master

[buildozer]
log_level = 2
warn_on_root = 1
