# Third-party notices

Stockfish 19 is Copyright (C) the Stockfish developers and is distributed under GNU General Public License version 3 or later (GPL-3.0-or-later).

Official source (tag sf_19): https://github.com/official-stockfish/Stockfish/tree/sf_19
Official project: https://stockfishchess.org/

When distributing a binary containing Stockfish, comply with GPLv3, including providing the applicable license and corresponding source or a valid offer/pointer to it.
