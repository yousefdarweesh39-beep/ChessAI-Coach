# Chess AI Coach — Android prototype

Native Kotlin Android project for the first UI and screen-consent prototype.

## Current prototype features
- Dark Android UI with a chessboard preview.
- Arabic/English toggle.
- Very-fast/Balanced setting toggle (UI state only; engine tuning is not integrated).
- Starts Android's screen-capture consent picker. On supported Android versions, the user can choose to share one app window.
- Explicitly reports that automatic recognition and engine analysis are not active yet.
- GitHub Actions workflow configured to build a debug APK artifact.

## Not implemented yet
- Stockfish/UCI engine integration and NNUE model.
- Frame capture loop, board detection, piece recognition, and position confidence checks.
- Legal chess rules, best-move calculation, variations, evaluation, PGN import/export, and game review.
- Foreground service lifecycle for ongoing screen capture.

## Build locally
Open in Android Studio with Android SDK and Gradle installed, sync, then run `gradle assembleDebug`. Output should be `app/build/outputs/apk/debug/app-debug.apk`.

## Build using GitHub Actions
Push to the `main` branch or manually run **Build Android APK** in Actions. Download the `chess-ai-coach-debug-apk` artifact from a successful workflow run.

## Planned engineering work
1. Add a maintained chess rules library and legal-position/FEN/PGN support.
2. Bundle a compatible Stockfish engine and NNUE network for offline analysis, with license notices and GPLv3 compliance.
3. Implement MediaProjection foreground-service lifecycle, frame throttling, board localization, and piece recognition with confidence scoring.
4. Validate recognized positions against legal moves; ask for correction instead of making an uncertain recommendation.
5. Benchmark latency, memory, battery and thermal behavior on target Android devices. A 5–5.5 second budget is a target, not a guarantee that every position is solved optimally.

This project is a prototype, not a finished chess assistant. The current build does not read shared-screen frames or calculate best moves.
