package com.example.chessaicoach

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

/** UI prototype. Screen-consent flow is wired; frame processing, OCR and Stockfish are still future integrations. */
class MainActivity : Activity() {
    private val bg = Color.rgb(16, 20, 28)
    private val panel = Color.rgb(29, 35, 46)
    private val green = Color.rgb(88, 166, 124)
    private var language = "ar"
    private var speed = "balanced"
    private var screenConsentGranted = false
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var analysis: TextView
    private lateinit var langButton: Button
    private lateinit var speedButton: Button
    private lateinit var captureButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 20)
            setBackgroundColor(bg)
        }
        root.addView(label("♟  CHESS AI COACH", 24f, Color.WHITE, true, Gravity.CENTER))
        root.addView(label(if (language == "ar") "مدرّب شطرنج محلي — نسخة تطوير" else "Offline chess coach — development build", 13f, Color.LTGRAY, false, Gravity.CENTER).apply { setPadding(0, 4, 0, 16) })

        val settings = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 0, 0, 10) }
        langButton = Button(this).apply { text = languageLabel(); setOnClickListener { language = if (language == "ar") "en" else "ar"; refreshUi() } }
        speedButton = Button(this).apply { text = speedLabel(); setOnClickListener { speed = if (speed == "balanced") "fast" else "balanced"; refreshUi() } }
        settings.addView(langButton, LinearLayout.LayoutParams(0, -2, 1f))
        settings.addView(speedButton, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(settings)

        val board = GridLayout(this).apply { columnCount = 8; rowCount = 8 }
        val boardPx = (resources.displayMetrics.widthPixels - (18 * 2 + 18 * 2)).coerceAtLeast(240)
        val size = boardPx / 8
        val pieces = arrayOf(
            arrayOf("♜","♞","♝","♛","♚","♝","♞","♜"), arrayOf("♟","♟","♟","♟","♟","♟","♟","♟"),
            arrayOf("","","","","","","",""), arrayOf("","","","","","","",""),
            arrayOf("","","","","","","",""), arrayOf("","","","","","","",""),
            arrayOf("♙","♙","♙","♙","♙","♙","♙","♙"), arrayOf("♖","♘","♗","♕","♔","♗","♘","♖")
        )
        for (r in 0..7) for (c in 0..7) {
            val cell = TextView(this).apply {
                text = pieces[r][c]; textSize = 27f; gravity = Gravity.CENTER
                setTextColor(if (r < 2) Color.rgb(25, 28, 32) else Color.WHITE)
                setBackgroundColor(if ((r + c) % 2 == 0) Color.rgb(225, 218, 194) else Color.rgb(91, 126, 108))
            }
            board.addView(cell, GridLayout.LayoutParams().apply { width = size; height = size; rowSpec = GridLayout.spec(r); columnSpec = GridLayout.spec(c) })
        }
        root.addView(board)
        root.addView(label(if (language == "ar") "معاينة الرقعة فقط — قواعد النقلات لم تُدمج بعد" else "Board preview only — legal move rules are not integrated yet", 12f, Color.LTGRAY, false, Gravity.CENTER).apply { setPadding(0, 8, 0, 12) })

        captureButton = Button(this).apply {
            text = captureLabel()
            setOnClickListener { requestScreenShare() }
        }
        root.addView(captureButton)
        status = label(statusLabel(), 14f, Color.WHITE, true, Gravity.START).apply { setPadding(4, 12, 4, 6) }
        root.addView(status)
        analysis = label(analysisLabel(), 13f, Color.rgb(174, 210, 185), false, Gravity.START).apply { setPadding(4, 2, 4, 8) }
        root.addView(analysis)

        val info = TextView(this).apply {
            text = if (language == "ar") "النسخة الحالية لا تحلل الشاشة بعد. يلزم دمج Stockfish والتعرّف على القطع واختبارهما قبل الاعتماد على أي نقلة." else "This build does not analyze screen frames yet. Stockfish and board recognition must be integrated and tested before relying on any suggested move."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(10, 12, 10, 12); setBackgroundColor(panel)
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    private fun requestScreenShare() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Deprecated Android callback retained for broad API compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE) {
            screenConsentGranted = resultCode == RESULT_OK && data != null
            status.text = if (screenConsentGranted) {
                if (language == "ar") "تمت الموافقة على مشاركة الشاشة. قراءة الرقعة الآلية غير مفعّلة في هذه النسخة." else "Screen-share permission granted. Automatic board reading is not enabled in this build."
            } else {
                if (language == "ar") "لم تبدأ مشاركة الشاشة." else "Screen sharing was not started."
            }
            captureButton.text = captureLabel()
        }
    }

    private fun refreshUi() {
        langButton.text = languageLabel()
        speedButton.text = speedLabel()
        captureButton.text = captureLabel()
        status.text = statusLabel()
        analysis.text = analysisLabel()
        buildUi()
    }

    private fun languageLabel() = if (language == "ar") "اللغة: العربية" else "Language: English"
    private fun speedLabel() = if (language == "ar") (if (speed == "fast") "السرعة: سريع جدًا" else "السرعة: متوازن") else (if (speed == "fast") "Speed: Very fast" else "Speed: Balanced")
    private fun captureLabel() = if (language == "ar") (if (screenConsentGranted) "إعادة اختيار الشاشة" else "مشاركة شاشة تطبيق واحد") else (if (screenConsentGranted) "Choose screen again" else "Share one app screen")
    private fun statusLabel() = if (language == "ar") "جاهز للتجربة — لم يتم تشغيل المحرك بعد." else "Ready for testing — chess engine is not running yet."
    private fun analysisLabel() = if (language == "ar") (if (speed == "fast") "وضع السرعة السريعة محدد (واجهة فقط)." else "الوضع المتوازن محدد (واجهة فقط).") else (if (speed == "fast") "Very-fast mode selected (UI only)." else "Balanced mode selected (UI only).")

    private fun label(textValue: String, textSize: Float, color: Int, bold: Boolean, gravityValue: Int) = TextView(this).apply {
        text = textValue; this.textSize = textSize; setTextColor(color); gravity = gravityValue
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    companion object { private const val REQUEST_CAPTURE = 7412 }
}
